import pandas as pd
import numpy as np
import re

x = pd.read_csv("../OutputFiles/CSVs/case_files/5kb_zscore_binwise_results.csv")
print(x)
samp_li = list(x.columns)
samp_list =samp_li[1:]
x = x.transpose()
x_lis = x.values.tolist()
chr_lis = x_lis[0]
x_lis.pop(0)
x_labels = x.columns.tolist()
zx = pd.DataFrame(data=x_lis, columns = chr_lis)
zz = zx.transpose()
print(zz)

x_l = list(range(1,23))
x_l.append('X')
x_l.append('Y')
chrwise_l = []
xy_l = []
for xb in x_l:
    rex_chr = "^chr"+str(xb)+":.*$"
    rex_v = re.compile(rex_chr)
    temp = []
    for b in chr_lis:
        if rex_v.match(b):
            temp.append(b)
    chrwise_l.append(temp)
print(pd.DataFrame(data = chrwise_l))

for s in range(0,len(chrwise_l)):
	tempr = []
	l_s = chrwise_l[s]
	for t in l_s:
		vx = zz.loc[[t]]
		vx_l = vx.values.tolist()
		tempr.append(vx_l[0])
	cx = pd.DataFrame(data = tempr, index = l_s, columns = samp_list)
	cx.to_csv("../OutputFiles/CSVs/case_files/5kb_zscore_binwise_chr"+str(x_l[s])+".csv", encoding='utf-8', index=True)
