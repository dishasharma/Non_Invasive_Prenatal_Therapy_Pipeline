import pandas as pd
import numpy as np
import re

x = pd.read_csv("../OutputFiles/CSVs/control_files/files_5kb/alldone_binwise_results.csv")
samp_li = list(x.columns)
samp_list =samp_li[1:]
x_t = x.transpose()
xt_lis = x_t.values.tolist()
bin_lis = xt_lis[0]
xt_lis.pop(0)
x_sum = np.sum(xt_lis, axis =1)
print(x_sum)
xt_norm = []
for i in range(0,len(xt_lis)):
    temp_arr = []
    for j in xt_lis[i]:
        temp = (j*1000000)/x_sum[i]
        temp_arr.append(temp)
    xt_norm.append(temp_arr)
print(pd.DataFrame(data = xt_norm))
x_lis = np.transpose(xt_norm)


y = pd.read_csv("../OutputFiles/CSVs/case_files/files_5kb/gc_correction_results.csv")
samp_y_li = list(y.columns)
samp_y_list =samp_y_li[1:]
y_t = y.transpose()
yt_lis = y_t.values.tolist()
bin_y_lis = yt_lis[0]
yt_lis.pop(0)
y_sum = np.sum(yt_lis, axis =1)
print(y_sum)
yt_norm = []
for i in range(0,len(yt_lis)):
    temp_arr = []
    for j in yt_lis[i]:
        temp = (j*1000000)/y_sum[i]
        temp_arr.append(temp)
    yt_norm.append(temp_arr)
print(pd.DataFrame(data = yt_norm))
y_lis = np.transpose(yt_norm)


x_avg = []
x_std = []
for b in x_lis:
    avz = np.mean(b)
    sdt = np.std(b)
    x_avg.append(avz)
    x_std.append(sdt)

print(pd.DataFrame(data = x_avg))
print(pd.DataFrame(data = x_std))

z_zsc = []
for b in range(len(y_lis)):
    temp = []
    for i in range(0,len(y_lis[b])):
        b_lis = y_lis[b]
        sumr = ((b_lis[i]-x_avg[b])/x_std[b])
        temp.append(sumr)
    z_zsc.append(temp)

zer = pd.DataFrame(data = z_zsc, columns = samp_y_list, index = bin_y_lis)
zer.to_csv("../OutputFiles/CSVs/case_files/5kb_zscore_binwise_results.csv", encoding='utf-8', index = True)