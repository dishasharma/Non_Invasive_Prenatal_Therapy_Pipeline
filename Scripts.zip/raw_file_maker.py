from math import ceil
import numpy as np
from scipy import linalg
import itertools
import pandas as pd
import os
import glob
import collections
from matplotlib import pyplot as plt
import pylab as pl
import re

pre_list = []
ful_dir = "../BamToBedFiles/control_files/files_20kb"
ful_listing = glob.glob(os.path.join(ful_dir, '*20kb*')) #file e.g.: sample1_bam_bincount20kb.bed
for i in ful_listing:
    pre_ful = os.path.splitext(os.path.split(i)[-1])[0]          #prefix maker
    pre_list.append(pre_ful[15:26])
pre_list.sort()
#END OF PREFIX TABULATION
print(pre_list)
rex_sample = "^.*chr[0-9XY]{1,2}.bed.*$"  #file e.g.: sample1_bam_bincount20kb_chr1.bed
rex_v = re.compile(rex_sample)
#BEGINNING OF BED FILE PROCESSING
sam_dir = "../BamToBedFiles/control_files/files_20kb/ChrWiseBed"
sample_list = []
for s in pre_list:
    regex_file = '*' + s + '*.bed*'
    sample_x = glob.glob(os.path.join(sam_dir, regex_file))
    sample_x.sort()
    sample_list.append(sample_x)

#print(sample_list)
#fname = "binsize_method/test/chr1con1-bincount.bed"
#split into either chr_section wise or sample wise
sample_list_2 = [e for e in sample_list if e]
print(pd.DataFrame(data = sample_list_2))

read_list = []

corr_final = []

corr_bin_fin = []
for s_x in sample_list_2:
    i_b = 0
    corr_r_l = []
    corr_bin_l = []
    #print(s_x[0])
    for s_y in s_x:
        if rex_v.match(s_y):
            print("Processing", s_y)
            print(i_b)

            content = []
            content_binname = []
            content_readcount = []
            with open(s_y)as f:
                for line in f:
                    content.append(line.strip().split())
            for x in content:
                binname = x[0]+":"+x[1]+"-"+x[2]
                content_binname.append(binname)
                content_readcount.append(int(x[3]))
            corr_r_l.append(content_readcount)
            corr_bin_l.append(content_binname)
    flat_read_list = [item for sublist in corr_r_l for item in sublist]
    flat_bin_list = [item for sublist in corr_bin_l for item in sublist]
    corr_final.append(flat_read_list)

read_list = flat_bin_list

#print(pd.DataFrame(data=corr_final))
#print(pd.DataFrame(data=read_list))

results = pd.DataFrame(data = corr_final, columns = read_list, index = pre_list)
results_x = results.transpose()
results_x = results_x.fillna(0)
print(results_x)
results_x.to_csv("../OutputFiles/CSVs/control_files/files_20kb/raw_read_file.csv", encoding='utf-8', index=True)